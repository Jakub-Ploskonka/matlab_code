clc; clear; close all;

fs = 100; N = 200; t0 = 0; Dt = 1/fs;
selSys = 5; ts = t0:Dt:t0+Dt*N-Dt;

switch selSys
    case 1
        b = [2, 3];
        a = [1, -1/2];
    case 2
        b = [2, 3];
        a = [1, 1/2];
    case 3
        b = [2, -1];
        a = [1, 3/2, -1/2];
    case 4
        b = [2, -1];
        a = [1, 1/2, -1/2];
% zad. 6
    case 5
        b = [1];
        a = [1, 1/2];
    case 6
        b = [1];
        a = [1, -1/2];
end

% zad.1
L = 80;

h = odp_imp_2(b,a,L);
ts2 = t0:Dt:t0+Dt*L-Dt;

h2 = impz(b,a,L);
L2 = length(h2);
ts3 = t0:Dt:t0+Dt*L2-Dt;

figure(1)
    stem(ts2,h,"b"); hold on; grid on;
    stem(ts3,h2,"kx");
    xlim([t0,(t0+Dt*N)/2]);
    title("h(t)");
    xlabel("t(s)");
    legend(["Funkcja własna" "Funkcja wbudowana"]);

% zad.2

Hcz = fft(h);
K = length(h);
Df = fs/K;

fh = 0:Df:Df*K-Df;

K2 = round(K/2);

if (mod(K,2) == 0)
    f_shifted = -fs/2:Df:fs/2-Df;
else
    f_shifted = -fs/2+Df/2:Df:fs/2-Df/2;
end

figure(2);
    subplot(2,1,1);
        plot(fh, 20*log10(abs(Hcz)), "m"); hold on; grid on;
        xlim([0,fs/2]);
        title("Moduł");
        xlabel("f(Hz)");
        ylabel("Magnituda w dB");
    subplot(2,1,2);
        plot(fh, angle(Hcz)*360/(2*pi), "m");hold on; grid on;
        xlim([0,fs/2]);
        title("Faza");
        xlabel("f(Hz)");
        ylabel("Faza w stopniach");
figure(3)
    freqz(b,a,N,fs);

% zad.3

x = xpi((ts-0.7)/0.99);
y = odp_sys(x,b,a,L);

y2 = filter(b,a,x);
ts2 = t0:Dt:t0+Dt*L-Dt;

figure(4);
    subplot(2,1,1); 
        stem(ts,x,"r");title("x(t)");hold on; grid on;
         xlabel("t(s)");
    subplot(2,1,2);
        stem(ts2,y,"g");hold on; grid on;
        stem(ts,y2,"kx");
        xlim([t0,t0+Dt*N-Dt]);
        title("y(t)");
        legend(["Funkcja własna" "Funkcja wbudowana"]);

% zad.4
[z_y, p_y, k_y] = tf2zpk(b, a);

z = roots(b);
p = roots(a);
circle = nsidedpoly(1000, 'Center', [0 0], 'Radius', 1);

figure(10);
    plot(circle, 'FaceColor', 'none'); axis equal; hold on; grid on;
    stem(real(z),imag(z),"mo");
    stem(real(p),imag(p),"rx");
    title("Rozkład zer i biegunów");
    xlabel("Real");
    ylabel('Imaginary');

figure(6)
    zplane(z_y,p_y);

%zad.5
X=-4:0.01:4;
Y=-4:0.01:4;

%Hz=ZTransform(x,X,Y);
